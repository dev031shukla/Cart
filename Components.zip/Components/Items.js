import React from 'react';




const Items = ({ ProductName, Description, Price, Image, Quantity  }) => {
    return (
        <>
        <div className="items-info" >
            <div className="product-img">
                  <img src={Image} alt="tp" />
            </div>

             <div className="title">
                 <h2>{ProductName}</h2>
                 <p>{Description}</p>
             </div>
             <div className="add-minus-quantity">
             <i className="fas fa-minus minus"></i>
                 <input type="text"  placeholder={Quantity} />
                 <i className="fas fa-plus add"></i>
             </div>
             <div className="price">
                 <h3>{Price}</h3>
             </div>
             <div className="remove-item">
                 <i className="fas fa-trash-alt remove"></i>

             </div>
            </div>
        <hr />
        </>
    )
}

export default Items;