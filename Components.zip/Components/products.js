export const products=[{
            id:1,
            ProductName:"Shell Advance",
            Description:"Two wheeler engine oil",
            Price:"400Rs",
            Quantity:1,
            Image:"https://www.shell.in/motorists/oils-lubricants/advance-motorcycle-engine-oils/advance-4-stroke-motorcycle-oil/shell-advance-ax5/_jcr_content/par/productDetails/image.img.960.jpeg/1470846788605/advance-ax5-10w-30.jpeg?imwidth=960"
},
{
            id:2,
            ProductName:"Shell Helix",
            Description:"Two wheeler engine oil",
            Price:"600Rs",
            Quantity:1,
            Image:"https://m.media-amazon.com/images/I/71k-Umf8AgL._SY355_.jpg"
},
]
